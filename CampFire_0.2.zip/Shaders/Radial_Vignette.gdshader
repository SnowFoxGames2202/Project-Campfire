shader_type canvas_item;

uniform float radius : hint_range(0.0, 1.0) = 0.5;
uniform vec4 dark_color : source_color = vec4(0.0, 0.0, 0.0, 1.0);

void fragment() {
    vec2 uv = UV;
    vec2 center = vec2(0.5);
    float dist = distance(uv, center);

    float fade = smoothstep(radius, radius + 0.2, dist);
    COLOR = dark_color * fade;
}
